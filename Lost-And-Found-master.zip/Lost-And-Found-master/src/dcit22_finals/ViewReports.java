package dcit22_finals;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewReports extends JFrame {
    private static final String URL = "jdbc:mysql://localhost/dcit55";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    public ViewReports() {
        setTitle("View Reports");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnNames = {"Report ID", "Type", "Phone Number", "Item Name", "Description", "Date", "Status"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);

        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            String query = "SELECT id, item_type, phone_number, item_name, description, date, status FROM items";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                while (rs.next()) {
                    int id = rs.getInt("id");
                    String type = rs.getString("item_type");
                    String phoneNumber = rs.getString("phone_number");
                    String itemName = rs.getString("item_name");
                    String description = rs.getString("description");
                    String date = rs.getString("date");
                    String status = rs.getString("status");
                    model.addRow(new Object[]{id, type, phoneNumber, itemName, description, date, status});
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ViewReports viewReports = new ViewReports();
            viewReports.setVisible(true);
        });
    }
}

